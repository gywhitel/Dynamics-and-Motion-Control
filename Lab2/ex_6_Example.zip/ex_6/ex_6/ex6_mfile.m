%ex 6 data
ro = 1000; %oil density[kg/m^3 ]
d_cyl = 0.05; %cylinder inner diameter [m]
d_piston = 0.02; %piston rod diameter [m]
l_stroke = 0.7; %maximum piston stroke [m]
m_total = 100; %total moving mass [kg]
d = 200; %linear friction coefficient [Ns/m]
Rv = 1e-4; %flow constant
ps = 20e6; %supply pressure, 
Beta = 2e9; %Bulk modulus
%%
Cf_1 = l_stroke*(d_cyl/2)^2*pi/Beta; %fluid capacitance, for 1st state
Cf_2 = l_stroke*(d_cyl/2 - d_piston/2)^2*pi/Beta; % fluid capacitance, for 2nd state

A_1 = (d_cyl/2)^2*pi; % Area of the 1st stage
A_2 = (d_cyl/2)^2*pi - (d_piston/2)^2*pi; %Area of the 2nd stage

%%
xv = 0.0005; % valve opening
